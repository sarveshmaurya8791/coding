public class locus {
}
